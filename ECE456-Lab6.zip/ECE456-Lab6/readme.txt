Tyler Feist
Lab #6
ECE 456

TCP/UDP Remote Command Program using Python and Geni

Instructions:

Server:
1) navigate to the directory with rcmdd.py in it via the command line on the server geni node
2) rcmdd.py requires 1 command line argument: portNumber
3) run "python3 rcmdd.py <portNumber>"
4) the script will ask the user if they want to run in TCP or UDP mode
5) depending on the choice the script will either wait for a TCP connection or a UDP message
6) once it receives a command it will run it and return the output with a timestamp

Client:
1) navigate to the directory with rcmd.py in it via the command line on the client geni node
3) rcmd.py requires 5 command line arguments: serverName, portNumber, executionCount, delayBetweenExecutions, and command
4) run "python3 rcmd.py <serverName> <portNumber> <executionCount> <delayBetweenExecutions> <command>"
5) the script will ask the user if they want to run in TCP or UDP mode. This must be the same as the server
6) The script will then open up a TCP connection to send the command or just send the command using UDP
7) the output of the command ran by the server will finally be displayed with a timestamp
